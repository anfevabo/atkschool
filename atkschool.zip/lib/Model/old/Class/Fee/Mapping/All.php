<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class Model_Class_Fee_Mapping_All extends Model_Class_Fee_Mapping {
    function init(){
        parent::init(true);
    }
}