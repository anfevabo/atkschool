<?php
class Model_MS_Designer extends Model_Table {
	var $table = "marksheet_designer";

	function init(){
		parent::init();

		$this->addField("name")->caption("Marksheet Name");
		$this->hasOne("Class","class_id");
		$this->hasOne("Session","session_id");
		$this->hasMany("MS_Sections","marksheet_designer_id");
		$this->addCondition('session_id',$this->add('Model_Sessions_Current')->tryLoadAny()->get('id'));
	}
}