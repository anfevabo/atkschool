<?php

class Model_FeeClassMapping extends Model_Table{
	var $table="fee_class_mapping";

	function init(){
		parent::init();
		$this->hasOne('Fee','fee_id');
		$this->hasOne('Class','class_id');
		$this->hasOne('Session','session_id');

		$this->hasMany('Fees_Applicable','fee_class_mapping_id');

		$this->addHook('beforeSave',$this);
		$this->addHook('afterSave',$this);
	}

	function beforeSave(){
		if(!$this->loaded()){
			$fcm=$this->add('Model_FeeClassMapping');
			$fcm->addCondition('fee_id',$this['fee_id']);
			$fcm->addCondition('class_id',$this['class_id']);
			$fcm->addCondition('session_id',$this['session_id']);
			$fcm->tryLoadAny();
			if($fcm->loaded())
				throw $this->exception("This is allready Exists");
			$this->memorize('newEntry',true);
		}
	}

	function afterSave(){
		if($this->recall('newEntry',false)){
			// This is new saved entry not edited
			
		}
	}

}