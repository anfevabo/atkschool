ALTER TABLE `student` ADD COLUMN `isScholared` BIT(1) NULL DEFAULT NULL  AFTER `roll_no` ;
