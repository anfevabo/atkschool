<?php
class page_student_feechart extends Page{
	function init(){
		parent::init();

		$crud=$this->add('CRUD');
		
	}

}