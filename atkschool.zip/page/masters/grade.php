<?php
class page_masters_grade extends Page{
	function init(){
		parent::init();

		$crud=$this->add("CRUD");
		$crud->setModel("Grade");
	}
}