<?php
class page_users extends xavoc_acl\page_user_management {
	function init(){
		parent::init();

	}
}