<?php
class page_hostel_disease extends page{
	function init(){
		parent::init();
		
	}
} 