<?php
class Exception_NotFound extends BaseException{}
