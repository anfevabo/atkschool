<?php
/**
 * Any time access to somewhat denied
 * 
 * @author Camper (cmd@adevel.com) on 29.04.2009
 */
class Exception_AccessDenied extends BaseException{}
