<?php
/**
 * 
 * @author Camper (cmd@adevel.com) on 04.06.2009
 */
class Exception_NotImplemented extends BaseException{}
