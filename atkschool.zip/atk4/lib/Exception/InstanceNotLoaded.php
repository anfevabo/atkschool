<?php
/**
 * Thrown wen instance of the class is referenced but not loaded
 * 
 * @author Camper (cmd@adevel.com) on 16.09.2009
 */
class Exception_InstanceNotLoaded extends Exception_InitError{}
