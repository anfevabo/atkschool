<?php
class Exception_Logic extends BaseException {}
