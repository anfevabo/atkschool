<?php
class FieldDefinition extends MVCFieldDefinition {}
