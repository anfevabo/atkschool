<?php
include '../../../atk4/loader.php';
$api=new Admin('rentaladmin','default');
$api->main();
