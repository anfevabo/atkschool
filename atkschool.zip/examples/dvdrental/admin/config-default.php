<?php
include_once'../config-default.php';
$config['atk']['base_path']='../'.$config['atk']['base_path'];
$config['auth']['key']='secret';
