<?php
include '../../atk4/loader.php';
$api=new Blog('MyBlog');
$api->main();
